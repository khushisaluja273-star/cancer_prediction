# Breast Cancer Risk Predictor

## Overview
A Flask web app that predicts breast cancer risk from cell nucleus measurements using Logistic Regression trained on the Wisconsin Breast Cancer dataset.

## Architecture
- **`app.py`** — Flask backend. Trains the model at startup and serves `/predict` (POST) for predictions.
- **`main.py`** — Standalone script showing baseline vs. chi-square feature selection accuracy.
- **`templates/index.html`** — Single-page frontend with a 30-feature form grouped into Mean, Error, and Worst value sections.

## Running the App
The workflow `Start application` runs `python app.py` on port 5000.

## Model Details
- Dataset: `sklearn.datasets.load_breast_cancer` (569 samples, 30 features)
- Algorithm: Logistic Regression (`max_iter=5000`)
- Preprocessing: StandardScaler
- Train/test split: 70/30, `random_state=42`
- Baseline accuracy: ~98.2%

## Dependencies
- Python 3.11
- flask, scikit-learn, numpy, pandas, matplotlib (managed via uv/pyproject.toml)
