import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import time

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import SelectKBest, chi2

# Load dataset
data = load_breast_cancer()
X = data.data
y = data.target

# Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42
)

# Scale
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Baseline Model
model = LogisticRegression(max_iter=5000)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
print("Baseline Accuracy:", accuracy_score(y_test, y_pred))

# Feature Selection - Chi Square (top 10 features)
selector = SelectKBest(score_func=chi2, k=10)
X_train_chi = selector.fit_transform(abs(X_train), y_train)
X_test_chi = selector.transform(abs(X_test))
model.fit(X_train_chi, y_train)
y_pred = model.predict(X_test_chi)
print("Chi-Square Accuracy:", accuracy_score(y_test, y_pred))

# Feature Selection - using all features
selector = SelectKBest(score_func=chi2, k='all')
X_train_chi = selector.fit_transform(abs(X_train), y_train)
X_test_chi = selector.transform(abs(X_test))
model.fit(X_train_chi, y_train)
y_pred = model.predict(X_test_chi)
print("Chi-Square Accuracy after using more features:", accuracy_score(y_test, y_pred))
